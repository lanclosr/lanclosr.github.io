Data sources for final project: UW Geog575 - Ryan Lanclos

FEMA:
	Damage
	HarrisCountyDamage
	HarrisCountyFloodplain

Harris County Flood Control District:
	HarrisCountyWatersheds
	watershedtopo

Ryan Lanclos:
	watershedAttributes
	watershedMap

	NOTE: created using Esri geoenrichment. Attributes also integrated into other data sets above for use in charts and graphs.